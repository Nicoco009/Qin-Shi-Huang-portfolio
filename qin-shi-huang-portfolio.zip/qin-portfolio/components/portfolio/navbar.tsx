"use client"

import React, { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

const navLinks = [
  { name: "Accueil", href: "#home" },
  { name: "Biographie", href: "#about" },
  { name: "Conquêtes", href: "#projects" },
  { name: "Héritage", href: "#services" },
  { name: "Ragnarök", href: "#contact" },
]

export function Navbar() {
  const [activeSection, setActiveSection] = useState("home")
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
      const sections = navLinks.map((link) => link.href.slice(1))
      const current = sections.find((section) => {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          return rect.top <= 150 && rect.bottom >= 150
        }
        return false
      })
      if (current) setActiveSection(current)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const element = document.getElementById(href.slice(1))
    if (element) element.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <nav className={cn("fixed top-6 left-1/2 -translate-x-1/2 z-50 transition-all duration-300", isScrolled ? "top-4" : "top-6")}>
      <div className="glass rounded-full px-2 py-2 flex items-center gap-1 border border-[#c8992a]/20">
        {navLinks.map((link) => (
          <a
            key={link.name}
            href={link.href}
            onClick={(e) => scrollToSection(e, link.href)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all duration-300",
              activeSection === link.href.slice(1)
                ? "bg-gradient-to-r from-[#8b1a1a] to-[#6b1010] text-[#c8992a] shadow-lg shadow-[#8b1a1a]/30 border border-[#c8992a]/30"
                : "text-[#f0e6d0]/50 hover:text-[#f0e6d0] hover:bg-[#c8992a]/10"
            )}
          >
            {link.name}
          </a>
        ))}
      </div>
    </nav>
  )
}
