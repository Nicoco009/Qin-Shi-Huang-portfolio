"use client"

import { Crown, Sword } from "lucide-react"

export function AboutSection() {
  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="glass-strong rounded-3xl p-8 md:p-12 grid md:grid-cols-2 gap-12 items-center scroll-animate">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#c8992a]/10 border border-[#c8992a]/30 text-[#c8992a] text-xs font-medium">
              <span className="w-2 h-2 bg-[#c8992a] rounded-full animate-pulse" />
              Champion des Dieux · Record of Ragnarök
            </span>

            <div className="space-y-2">
              <p className="text-xs font-mono tracking-[0.3em] text-[#c8992a]/60">秦始皇</p>
              <h2 className="text-4xl md:text-5xl font-bold text-[#f0e6d0]">
                Qin <span className="text-gradient">Shi Huang</span>
              </h2>
              <p className="text-xl text-[#f0e6d0]/60">259 AV. J.-C. — 210 AV. J.-C.</p>
            </div>

            <p className="text-[#f0e6d0]/60 leading-relaxed">
              Né Ying Zheng, il devient roi de Qin à treize ans. À 38 ans, après avoir vaincu 
              les six royaumes rivaux, il fonde la première dynastie impériale unifiée de Chine 
              et se proclame <em className="text-[#c8992a]">Shi Huangdi</em> — Premier Auguste Empereur.
            </p>

            <p className="text-[#f0e6d0]/60 leading-relaxed">
              Standardisation de l'écriture, des poids et mesures, construction de la Grande Muraille, 
              armée en terre cuite de 8 000 soldats. Son règne remodèle une civilisation entière. 
              Dans le Ragnarök, il combat pour les dieux avec une puissance absolue — 
              maîtrisant les <span className="text-[#c8992a]">72 transformations</span>.
            </p>

            <div className="grid grid-cols-3 gap-4 pt-4">
              {[
                { label: "Royaumes", value: "7", sub: "unifiés" },
                { label: "Règne", value: "15", sub: "ans" },
                { label: "Armée", value: "8K+", sub: "soldats" },
              ].map((stat) => (
                <div key={stat.label} className="glass rounded-2xl p-4 text-center border border-[#c8992a]/20">
                  <div className="text-2xl font-bold text-gradient">{stat.value}</div>
                  <div className="text-xs text-[#f0e6d0]/80 font-medium">{stat.label}</div>
                  <div className="text-xs text-[#f0e6d0]/40">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-[#c8992a]/20 rounded-2xl blur-3xl" />
              <div className="relative glass rounded-2xl p-4 animate-float border border-[#c8992a]/20">
                <div className="w-64 h-64 md:w-80 md:h-80 rounded-xl overflow-hidden bg-gradient-to-br from-[#8b1a1a]/30 to-[#c8992a]/10 flex items-center justify-center">
                  <img
                    src="/images/profile.jpg"
                    alt="Qin Shi Huang"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.currentTarget as HTMLImageElement
                      target.style.display = "none"
                      const parent = target.parentElement
                      if (parent) {
                        parent.innerHTML = `<div class="flex flex-col items-center justify-center w-full h-full gap-4">
                          <div style="font-size:6rem;color:#c8992a;text-shadow:0 0 40px rgba(200,153,42,0.6);font-family:serif">秦</div>
                          <div style="font-size:0.75rem;letter-spacing:0.3em;color:rgba(200,153,42,0.7)">QIN SHI HUANG</div>
                        </div>`
                      }
                    }}
                  />
                </div>
                <div className="absolute -bottom-3 -right-3 glass px-4 py-2 rounded-full text-xs font-mono border border-[#c8992a]/30">
                  <span className="text-[#c8992a]">始</span> Premier Empereur
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
