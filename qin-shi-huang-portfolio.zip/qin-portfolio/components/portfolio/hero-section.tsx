"use client"

import React from "react"
import { Crown, Sword, Scroll, Shield, Zap } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="min-h-screen relative flex items-center overflow-hidden">
      <div className="absolute top-1/3 left-1/4 w-[700px] h-[700px] bg-[#8b1a1a]/15 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[500px] h-[500px] bg-[#c8992a]/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <svg className="absolute top-0 left-0 w-full h-full opacity-5" viewBox="0 0 1200 800">
          <pattern id="chinese-grid" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
            <rect x="0" y="0" width="80" height="80" fill="none" stroke="#c8992a" strokeWidth="0.5" />
            <rect x="10" y="10" width="60" height="60" fill="none" stroke="#c8992a" strokeWidth="0.3" />
          </pattern>
          <rect width="1200" height="800" fill="url(#chinese-grid)" />
        </svg>
      </div>

      <div className="container mx-auto px-6 py-20 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <div className="space-y-8">
          <div className="flex flex-wrap gap-3">
            <span className="glass px-4 py-2 rounded-full text-xs font-mono text-[#c8992a] flex items-center gap-2">
              <Crown className="w-3 h-3" />
              PREMIER EMPEREUR
            </span>
            <span className="glass px-4 py-2 rounded-full text-xs font-mono text-[#f0e6d0]/60 flex items-center gap-2">
              <Zap className="w-3 h-3" />
              221 AV. J.-C.
            </span>
          </div>

          <div className="space-y-4">
            <p className="text-xs font-mono tracking-[0.4em] text-[#c8992a]/70 uppercase">始皇帝 · Shǐ Huáng Dì</p>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
              Qin{" "}
              <span className="text-gradient">Shi Huang</span>
            </h1>
            <p className="text-lg text-[#f0e6d0]/60 max-w-lg leading-relaxed">
              Le conquérant qui unifia sept royaumes. Fondateur du premier grand empire de Chine. 
              Champion des dieux dans le Ragnarök — invaincu, implacable, éternel.
            </p>
          </div>

          <div className="flex flex-wrap gap-4">
            <a href="#about" className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b1a1a] to-[#6b1010] text-[#f0e6d0] text-sm font-medium flex items-center gap-2 hover:shadow-lg hover:shadow-[#8b1a1a]/40 transition-all hover:-translate-y-0.5">
              <Crown className="w-4 h-4 text-[#c8992a]" />
              L'Empereur
            </a>
            <a href="#projects" className="glass px-6 py-3 rounded-xl flex items-center gap-2 text-sm font-medium hover:bg-[#c8992a]/10 transition-all group">
              <Sword className="w-4 h-4 text-[#c8992a] group-hover:scale-110 transition-transform" />
              Conquêtes
            </a>
            <a href="#services" className="glass px-6 py-3 rounded-xl flex items-center gap-2 text-sm font-medium hover:bg-[#c8992a]/10 transition-all group">
              <Scroll className="w-4 h-4 text-[#c8992a] group-hover:scale-110 transition-transform" />
              Héritage
            </a>
          </div>
        </div>

        <div className="relative flex items-center justify-center">
          <ImperialSeal />
        </div>
      </div>
    </section>
  )
}

function ImperialSeal() {
  return (
    <div className="relative w-[350px] h-[350px] md:w-[450px] md:h-[450px]">
      <div className="absolute inset-0 animate-rotate">
        <svg viewBox="0 0 400 400" className="w-full h-full">
          <defs>
            <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e8b84b" />
              <stop offset="50%" stopColor="#c8992a" />
              <stop offset="100%" stopColor="#8b6010" />
            </linearGradient>
          </defs>
          <circle cx="200" cy="200" r="190" fill="none" stroke="url(#gold-gradient)" strokeWidth="1.5" strokeDasharray="15 8" opacity="0.7" />
        </svg>
      </div>

      <div className="absolute inset-6 animate-rotate" style={{ animationDirection: "reverse", animationDuration: "30s" }}>
        <svg viewBox="0 0 400 400" className="w-full h-full">
          <circle cx="200" cy="200" r="185" fill="none" stroke="#8b1a1a" strokeWidth="1" strokeDasharray="4 20" opacity="0.5" />
          {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => {
            const rad = (angle * Math.PI) / 180
            const x = 200 + 185 * Math.cos(rad)
            const y = 200 + 185 * Math.sin(rad)
            return <circle key={i} cx={x} cy={y} r="4" fill="#c8992a" opacity="0.8" />
          })}
        </svg>
      </div>

      <div className="absolute inset-14 animate-rotate" style={{ animationDuration: "15s" }}>
        <svg viewBox="0 0 400 400" className="w-full h-full">
          <circle cx="200" cy="200" r="175" fill="none" stroke="#c8992a" strokeWidth="0.5" strokeDasharray="8 12" opacity="0.3" />
        </svg>
      </div>

      <div className="absolute inset-20 glass rounded-full flex items-center justify-center animate-pulse-glow border border-[#c8992a]/30">
        <div className="text-center space-y-3">
          <div className="text-4xl font-bold" style={{ fontFamily: "serif", color: "#c8992a", textShadow: "0 0 20px rgba(200,153,42,0.5)" }}>
            秦
          </div>
          <div className="text-xs font-mono tracking-widest text-[#c8992a]/80">INVAINCU</div>
          <div className="flex items-center justify-center gap-3 pt-1">
            <StatItem icon={<Sword className="w-3 h-3" />} label="Victoires" value="∞" />
            <StatItem icon={<Shield className="w-3 h-3" />} label="Défaites" value="0" />
          </div>
        </div>
      </div>

      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-10 bg-gradient-to-b from-[#c8992a] to-transparent" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0.5 h-10 bg-gradient-to-t from-[#c8992a] to-transparent" />
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-0.5 bg-gradient-to-r from-[#c8992a] to-transparent" />
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-0.5 bg-gradient-to-l from-[#c8992a] to-transparent" />
    </div>
  )
}

function StatItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 text-[#c8992a]">
        {icon}
        <span className="text-[10px] font-mono text-[#f0e6d0]/40">{label}</span>
      </div>
      <span className="text-sm font-semibold text-[#c8992a]">{value}</span>
    </div>
  )
}
