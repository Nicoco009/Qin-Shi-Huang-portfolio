"use client"

import { Crown, Scroll, Sword, Shield, Mountain, Zap } from "lucide-react"

const legacy = [
  {
    icon: Crown,
    title: "Titre Impérial",
    description: "Crée le titre de 皇帝 (Huángdì) — Auguste Empereur — fusionnant les titres des trois souverains mythiques et des cinq empereurs légendaires.",
  },
  {
    icon: Scroll,
    title: "Écriture Unifiée",
    description: "Standardise le système d'écriture chinois à travers tout l'empire, brisant les barrières linguistiques entre les anciens royaumes.",
  },
  {
    icon: Sword,
    title: "Armée en Terre Cuite",
    description: "8 000 soldats grandeur nature sculptés pour garder sa tombe. L'une des merveilles archéologiques les plus extraordinaires du monde.",
  },
  {
    icon: Shield,
    title: "Grande Muraille",
    description: "Ordonne la jonction et l'extension des murailles défensives existantes pour créer une frontière unifiée contre les invasions nomades du nord.",
  },
  {
    icon: Mountain,
    title: "Réseau de Routes",
    description: "Construction de plus de 7 000 km de routes impériales reliant tous les coins de l'empire, révolutionnant le commerce et la mobilité militaire.",
  },
  {
    icon: Zap,
    title: "72 Transformations",
    description: "Dans le Ragnarök, maîtrise absolue des transformations divines. Une puissance qui dépasse les limites humaines — le corps de l'Empereur devient l'arme ultime.",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-24 relative">
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-[#c8992a]/8 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 scroll-animate">
          <span className="text-xs font-mono text-[#c8992a] tracking-wider uppercase">Héritage Impérial</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-2 text-[#f0e6d0]">
            Réformes & <span className="text-gradient">Pouvoir</span>
          </h2>
          <p className="text-[#f0e6d0]/50 mt-4 max-w-2xl mx-auto">
            Les transformations imposées par Qin Shi Huang ont façonné la Chine 
            pour les deux millénaires suivants — et au-delà.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {legacy.map((item, index) => (
            <LegacyCard key={item.title} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function LegacyCard({ item, index }: { item: typeof legacy[0]; index: number }) {
  const Icon = item.icon
  return (
    <div
      className="group glass rounded-2xl p-8 text-center hover:border-[#c8992a]/40 transition-all duration-300 hover:-translate-y-2 relative overflow-hidden scroll-animate"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#c8992a]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="relative mb-6 inline-flex">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8b1a1a] to-[#5a1010] flex items-center justify-center group-hover:shadow-lg group-hover:shadow-[#8b1a1a]/40 transition-all border border-[#c8992a]/20">
          <Icon className="w-8 h-8 text-[#c8992a]" />
        </div>
      </div>

      <div className="relative space-y-3">
        <h3 className="text-xl font-semibold group-hover:text-[#c8992a] transition-colors text-[#f0e6d0]">
          {item.title}
        </h3>
        <p className="text-[#f0e6d0]/50 text-sm leading-relaxed">
          {item.description}
        </p>
      </div>
    </div>
  )
}
