"use client"

import React from "react"
import { Sword, Crown, Shield, Scroll } from "lucide-react"

const ragnarokFacts = [
  {
    icon: Crown,
    label: "Désigné par",
    value: "Les Dieux",
  },
  {
    icon: Sword,
    label: "Arme",
    value: "Les 72 Transformations",
  },
  {
    icon: Shield,
    label: "Statut",
    value: "Champion",
  },
]

const quotes = [
  {
    text: "Je suis celui qui a unifié le ciel et la terre. Aucun homme, aucun dieu ne peut me vaincre.",
    context: "Record of Ragnarök",
  },
  {
    text: "Un empire ne se bâtit pas avec des compromis. Il se bâtit avec du fer et de la volonté.",
    context: "Histoire de Qin",
  },
  {
    text: "La mort n'est qu'un ennemi parmi d'autres. Et je n'ai jamais perdu.",
    context: "Record of Ragnarök",
  },
]

export function ContactSection() {
  return (
    <section id="contact" className="py-24 relative">
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#c8992a]/8 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 scroll-animate">
          <span className="text-xs font-mono text-[#c8992a] tracking-wider uppercase">Shuumatsu no Valkyrie</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-2 text-[#f0e6d0]">
            Le <span className="text-gradient">Ragnarök</span>
          </h2>
          <p className="text-[#f0e6d0]/50 mt-4 max-w-2xl mx-auto">
            Dans le tournoi final entre dieux et humains, Qin Shi Huang est choisi 
            comme champion. Son adversaire : un dieu millénaire. Son arme : lui-même.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Stats Ragnarök */}
          <div className="space-y-6 scroll-animate">
            <div className="space-y-4">
              {ragnarokFacts.map((fact) => {
                const Icon = fact.icon
                return (
                  <div key={fact.label} className="glass rounded-2xl p-5 flex items-center gap-4 border border-[#c8992a]/15 hover:border-[#c8992a]/35 transition-all group">
                    <div className="w-12 h-12 rounded-xl bg-[#8b1a1a]/20 flex items-center justify-center group-hover:bg-[#8b1a1a]/30 transition-colors border border-[#c8992a]/20">
                      <Icon className="w-5 h-5 text-[#c8992a]" />
                    </div>
                    <div>
                      <p className="text-xs text-[#f0e6d0]/40 uppercase tracking-wider">{fact.label}</p>
                      <p className="text-[#f0e6d0] font-medium">{fact.value}</p>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Chinese characters decoration */}
            <div className="glass rounded-2xl p-6 text-center border border-[#c8992a]/15">
              <div className="flex justify-center gap-6 text-4xl" style={{ fontFamily: "serif", textShadow: "0 0 20px rgba(200,153,42,0.4)" }}>
                {["始", "皇", "帝"].map((char, i) => (
                  <span key={i} className="text-gradient">{char}</span>
                ))}
              </div>
              <p className="text-xs font-mono text-[#c8992a]/60 mt-3 tracking-widest">Shǐ · Huáng · Dì</p>
              <p className="text-xs text-[#f0e6d0]/40 mt-1">Premier · Auguste · Empereur</p>
            </div>
          </div>

          {/* Quotes */}
          <div className="space-y-6 scroll-animate">
            <div className="flex items-center gap-2 mb-6">
              <Scroll className="w-4 h-4 text-[#c8992a]" />
              <span className="text-sm text-[#f0e6d0]/60 uppercase tracking-wider font-mono">Paroles de l'Empereur</span>
            </div>
            {quotes.map((quote, index) => (
              <div key={index} className="glass-strong rounded-2xl p-6 border-l-2 border-[#c8992a]/50 hover:border-[#c8992a] transition-all">
                <p className="text-[#f0e6d0]/80 leading-relaxed italic text-sm">
                  &ldquo;{quote.text}&rdquo;
                </p>
                <p className="text-xs text-[#c8992a]/60 font-mono mt-3">— {quote.context}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
