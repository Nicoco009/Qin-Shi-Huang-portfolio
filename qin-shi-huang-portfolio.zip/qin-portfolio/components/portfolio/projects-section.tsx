"use client"

import { Sword, Crown } from "lucide-react"

const conquests = [
  {
    id: 1,
    title: "Royaume de Han",
    year: "230 AV. J.-C.",
    description: "Première des six conquêtes. Le royaume de Han, affaibli par les guerres internes, tombe en premier sous l'avancée des armées Qin.",
    tags: ["Stratégie militaire", "Diplomatie", "Infanterie"],
    result: "Victoire",
  },
  {
    id: 2,
    title: "Royaume de Zhao",
    year: "228 AV. J.-C.",
    description: "Après deux ans de siège, la capitale Handan tombe. Le général Wang Jian brise la résistance acharnée du Zhao.",
    tags: ["Siège", "Cavalerie", "Wang Jian"],
    result: "Victoire",
  },
  {
    id: 3,
    title: "Royaume de Wei",
    year: "225 AV. J.-C.",
    description: "Détournement du fleuve Jaune pour inonder la capitale Daliang. Une victoire par l'ingénierie autant que par les armes.",
    tags: ["Génie militaire", "Inondation", "Siège"],
    result: "Victoire",
  },
  {
    id: 4,
    title: "Royaume de Chu",
    year: "223 AV. J.-C.",
    description: "Le plus grand royaume, nécessitant 600 000 soldats. Wang Jian reprend le commandement après l'échec initial de Li Xin.",
    tags: ["600 000 soldats", "Wang Jian", "Campagne prolongée"],
    result: "Victoire",
  },
  {
    id: 5,
    title: "Royaume de Yan",
    year: "222 AV. J.-C.",
    description: "Le prince Dan avait tenté d'assassiner Ying Zheng. La réponse fut totale — le royaume de Yan est anéanti.",
    tags: ["Vengeance", "Nord", "Poursuite"],
    result: "Victoire",
  },
  {
    id: 6,
    title: "Royaume de Qi",
    year: "221 AV. J.-C.",
    description: "Le dernier des six royaumes. Sans combattre, le roi de Qi se rend. La Chine est unifiée pour la première fois de son histoire.",
    tags: ["Unification", "Reddition", "Fin des Royaumes Combattants"],
    result: "Unification",
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-24 relative">
      <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-[#8b1a1a]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 scroll-animate">
          <span className="text-xs font-mono text-[#c8992a] tracking-wider uppercase">230–221 AV. J.-C.</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-2 text-[#f0e6d0]">
            Les Six <span className="text-gradient">Conquêtes</span>
          </h2>
          <p className="text-[#f0e6d0]/50 mt-4 max-w-2xl mx-auto">
            En neuf ans, Ying Zheng soumet un à un les six royaumes rivaux 
            et forge l'empire le plus puissant que la Chine ait jamais connu.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {conquests.map((conquest, index) => (
            <ConquestCard key={conquest.id} conquest={conquest} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ConquestCard({ conquest, index }: { conquest: typeof conquests[0]; index: number }) {
  const isLast = index === conquests.length - 1
  return (
    <div
      className={`group glass rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:shadow-xl scroll-animate ${isLast ? "hover:border-[#c8992a]/50 hover:shadow-[#c8992a]/20" : "hover:border-[#8b1a1a]/40 hover:shadow-[#8b1a1a]/10"}`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      {/* Top bar */}
      <div className={`h-1 w-full ${isLast ? "bg-gradient-to-r from-[#c8992a] to-[#e8b84b]" : "bg-gradient-to-r from-[#8b1a1a] to-[#6b1010]"}`} />

      <div className="p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-xs font-mono text-[#c8992a]/60">{conquest.year}</span>
            <h3 className={`text-xl font-semibold mt-1 transition-colors ${isLast ? "group-hover:text-[#c8992a]" : "group-hover:text-[#8b1a1a]"} text-[#f0e6d0]`}>
              {conquest.title}
            </h3>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-mono ${isLast ? "bg-[#c8992a]/15 text-[#c8992a] border border-[#c8992a]/30" : "bg-[#8b1a1a]/15 text-[#f0e6d0]/70 border border-[#8b1a1a]/30"}`}>
            {conquest.result}
          </span>
        </div>

        <p className="text-[#f0e6d0]/50 text-sm leading-relaxed">
          {conquest.description}
        </p>

        <div className="flex flex-wrap gap-2">
          {conquest.tags.map((tag) => (
            <span key={tag} className="px-3 py-1 rounded-full bg-[#c8992a]/5 text-xs text-[#f0e6d0]/50 border border-[#c8992a]/10">
              {tag}
            </span>
          ))}
        </div>

        <div className="pt-2 flex items-center gap-2 text-xs text-[#c8992a]/60 font-mono">
          <Sword className="w-3 h-3" />
          <span>Armée de Qin</span>
          {isLast && <><Crown className="w-3 h-3 ml-2" /><span>Unification</span></>}
        </div>
      </div>
    </div>
  )
}
