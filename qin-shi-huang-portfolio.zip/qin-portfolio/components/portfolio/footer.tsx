"use client"

export function Footer() {
  return (
    <footer className="py-12 border-t border-[#c8992a]/10 relative z-10">
      <div className="container mx-auto px-6 text-center space-y-4">
        <div className="text-3xl font-bold" style={{ fontFamily: "serif", color: "#c8992a", textShadow: "0 0 20px rgba(200,153,42,0.3)" }}>
          秦始皇
        </div>
        <p className="text-xs font-mono text-[#f0e6d0]/30 tracking-widest">
          259 AV. J.-C. — L'EMPIRE ÉTERNEL — 始皇帝
        </p>
        <p className="text-xs text-[#f0e6d0]/20">
          Tribute fansite · Record of Ragnarök / Shuumatsu no Valkyrie
        </p>
      </div>
    </footer>
  )
}
