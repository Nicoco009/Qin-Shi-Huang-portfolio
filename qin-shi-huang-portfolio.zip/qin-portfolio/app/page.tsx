import { Navbar } from "@/components/portfolio/navbar"
import { HeroSection } from "@/components/portfolio/hero-section"
import { AboutSection } from "@/components/portfolio/about-section"
import { ProjectsSection } from "@/components/portfolio/projects-section"
import { ServicesSection } from "@/components/portfolio/services-section"
import { ContactSection } from "@/components/portfolio/contact-section"
import { Footer } from "@/components/portfolio/footer"
import { ScrollAnimator } from "@/components/portfolio/scroll-animator"

export default function PortfolioPage() {
  return (
    <main className="min-h-screen bg-[#080604] overflow-hidden">
      <ScrollAnimator />
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ProjectsSection />
      <ServicesSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
